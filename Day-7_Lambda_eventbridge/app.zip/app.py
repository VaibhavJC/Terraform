def lambda_handler(event, context):
    print("Hello from AWS Lambda!")
    return {
        "statusCode": 200,
        "body": "Hello from AWS Lambda!"
    }
